package com.auction.util;

import java.util.List;

import com.auction.model.Product;

public interface ProductDao {
                String insertProduct(Product p);
                Product getProduct(String pid);
                List<Product> getProducts();
                String deleteProduct(String pid);
                List<Product> search(String pid);

}
