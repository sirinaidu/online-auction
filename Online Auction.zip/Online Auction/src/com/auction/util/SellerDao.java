package com.auction.util;

import java.util.List;

import asd.Sale;

import com.auction.dao.ProductDaoImpl;
import com.auction.model.Product;
import com.auction.model.SalesInfo;
import com.auction.model.Seller;
import com.auction.model.User;

public interface SellerDao 
{
	List<Sale> sellerList(String seller_id);
	String insertSeller(String pid,String uid);
}
