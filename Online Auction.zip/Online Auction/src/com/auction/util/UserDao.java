package com.auction.util;

import java.util.List;

import com.auction.model.Product;
import com.auction.model.User;

public interface UserDao {
	  boolean insertUser(User u);
      User getUser(String uid);
      //List<User> getUsers();
}
