package com.auction.model;

public class Seller 
{
 private String seller_id;
 private String product_id;
public String getSeller_id() {
	return seller_id;
}
public void setSeller_id(String seller_id) {
	this.seller_id = seller_id;
}
public String getProduct_id() {
	return product_id;
}
public void setProduct_id(String product_id) {
	this.product_id = product_id;
}
public Seller(String seller_id, String product_id) {
	super();
	this.seller_id = seller_id;
	this.product_id = product_id;
}
public Seller() {
	super();
	// TODO Auto-generated constructor stub
}

 
}
