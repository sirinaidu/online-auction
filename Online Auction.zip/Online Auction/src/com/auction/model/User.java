package com.auction.model;

public class User {
	private String user_id;
	private String user_name;
	private String first_name;
	private String last_name;
	private String pwd;
	private String address;
	private String mobile_no;
	private String email;
	private String paypal_id;

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPaypal_id() {
		return paypal_id;
	}

	public void setPaypal_id(String paypal_id) {
		this.paypal_id = paypal_id;
	}

	public User(String user_id, String user_name, String first_name,
			String last_name, String pwd, String address, String mobile_no,
			String email, String paypal_id) {
		super();
		this.user_id = user_id;
		this.user_name = user_name;
		this.first_name = first_name;
		this.last_name = last_name;
		this.pwd = pwd;
		this.address = address;
		this.mobile_no = mobile_no;
		this.email = email;
		this.paypal_id = paypal_id;
	}

	@Override
	public String toString() {
		return "User [user_id=" + user_id + ", user_name=" + user_name
				+ ", first_name=" + first_name + ", last_name=" + last_name
				+ ", pwd=" + pwd + ", address=" + address + ", mobile_no="
				+ mobile_no + ", email=" + email + ", paypal_id=" + paypal_id
				+ "]";
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

}
