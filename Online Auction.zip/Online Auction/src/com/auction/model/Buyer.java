package com.auction.model;

public class Buyer {
	private String buyer_id;
	 private String product_id;
	public String getBuyer_id() {
		return buyer_id;
	}
	public void setBuyer_id(String buyer_id) {
		this.buyer_id = buyer_id;
	}
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
	public Buyer(String buyer_id, String product_id) {
		super();
		this.buyer_id = buyer_id;
		this.product_id = product_id;
	}
	public Buyer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	 
}
