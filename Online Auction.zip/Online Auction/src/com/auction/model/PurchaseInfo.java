package com.auction.model;

public class PurchaseInfo 
{
private String pname;
private double fprice;
private String desc;
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public Double getFprice() {
	return fprice;
}
public void setFprice(Double fprice) {
	this.fprice = fprice;
}
public String getDesc() {
	return desc;
}
public void setDesc(String desc) {
	this.desc = desc;
}
public PurchaseInfo(String pname, double fprice, String desc) {
	super();
	this.pname = pname;
	this.fprice = fprice;
	this.desc = desc;
}
public PurchaseInfo() {
	super();
	// TODO Auto-generated constructor stub
}

}
