package com.auction.model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Product {
      private String pid;
      private String name;
      private String shortdesc;
      private String desc;
      private String category;
      private double start_price;
      private Date bid_end_date;
      private double final_price;
      private Date start_date;
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShortdesc() {
		return shortdesc;
	}
	public void setShortdesc(String shortdesc) {
		this.shortdesc = shortdesc;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getStart_price() {
		return start_price;
	}
	public void setStart_price(double start_price) {
		this.start_price = start_price;
	}
	public Date getBid_end_date() {
		return bid_end_date;
	}
	public void setBid_end_date(Date bid_end_date) {
		this.bid_end_date = bid_end_date;
	}
	public double getFinal_price() {
		return final_price;
	}
	public void setFinal_price(double final_price) {
		this.final_price = final_price;
	}
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	public Product(String pid, String name, String shortdesc, String desc,
			String category, double start_price, Date bid_end_date,
			double final_price, Date start_date) {
		super();
		this.pid = pid;
		this.name = name;
		this.shortdesc = shortdesc;
		this.desc = desc;
		this.category = category;
		this.start_price = start_price;
		this.bid_end_date = bid_end_date;
		this.final_price = final_price;
		this.start_date = start_date;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Product [pid=" + pid + ", name=" + name + ", shortdesc="
				+ shortdesc + ", desc=" + desc + ", category=" + category
				+ ", start_price=" + start_price + ", bid_end_date="
				+ bid_end_date + ", final_price=" + final_price
				+ ", start_date=" + start_date + "]";
	}
    
	public String getSD()

	{

		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");

		String s=getStart_price()+"";

		return s;

	}

	public String getED()

	{

		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");

		String s=sdf.format(bid_end_date);

		return s;

	}

	public String getSP()

	{

		String s=start_price+"";

		return s;

	}
      
      
	
      
}

