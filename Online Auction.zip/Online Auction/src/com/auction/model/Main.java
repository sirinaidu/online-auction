package com.auction.model;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

import com.auction.dao.BuyerDaoImpl;
import com.auction.dao.ProductDaoImpl;
import com.auction.dao.SellerDaoImpl;
import com.auction.dao.UserDaoImpl;
import com.auction.model.Buyer;
import com.auction.model.Product;
import com.auction.model.Seller;
import com.auction.model.User;

public class Main {

                public static void main(String[] args)throws Exception {
                                Product p=new Product();
                                ProductDaoImpl pimpl=new ProductDaoImpl();
                                List<Product> productList=new ArrayList<>();
                                productList=pimpl.getProducts();
                                SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
                                
                                User user=new User();
                                UserDaoImpl uimpl=new UserDaoImpl();
                                
                                Buyer buyer=new Buyer();
                                BuyerDaoImpl bimpl=new BuyerDaoImpl();
                                
                                
                                Seller seller=new Seller();
                                SellerDaoImpl simpl=new  SellerDaoImpl();
                                
                             //product-----------------------------   
                                //to retrieve single product 
                                
                                /*p=pimpl.getProduct(21);
                               System.out.println(p);
                                 */
                       
                                
                                
                              /*  Product p1=new Product("51","pen", "black", "ball pen","pen",30.0,sdf.parse("2018-01-01"),60.0,sdf.parse("2018-02-01"));
                         
                                String s=pimpl.insertProduct(p1);
                                System.out.println(s);*/
                                
                                //all products
                                productList=pimpl.getMyProducts("shubham123");
                               for(Product e:productList)
                                    System.out.println(e);
                              
                                
                         //user----------------       
                                //insert user
                                
                                
                                
                             /*  boolean s=uimpl.insertUser(new User("5","k","e","f","99ad","ab","850012", "k@g","p9"));
                               System.out.println(s);
                                */
                                //get user details
                                
                                	//System.out.println(uimpl.getUser("a"));
                                
                          //buyer------------------------
                                //mypurchase
                               //bimpl.buyerList("2");
                                
                                
                                
                                
                            //seller------------------
                                //mysales
                               /* simpl.sellerList("3");*/
                                
                                
                                //recentBid
                                
                                //System.out.println(pimpl.getRecentBid("0069040922772064158196405559216569691967"));
                                
                }

}
