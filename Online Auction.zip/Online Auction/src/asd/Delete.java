package asd;



import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.auction.dao.ProductDaoImpl;



@WebServlet("/Delete")

public class Delete extends HttpServlet {

	static String s1="";

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String s=request.getParameter("Delete Products");

		System.out.println(s);
		ProductDaoImpl pimpl=new ProductDaoImpl();
		System.out.println(pimpl.deleteProduct(s));
		if(s.equals("Delete Products"))
			s1="not delete";
		else
		s1="delete";
		response.sendRedirect("profile.jsp");

	}

	public static String getS1() {
		return s1;
	}

	public static void setS1(String s1) {
		Delete.s1 = s1;
	}



}