package asd;



import com.auction.dao.UserDaoImpl;
import com.auction.model.User;

public class Main {
	public static void main(String[] args) {
		UserDaoImpl ud=new UserDaoImpl();
		User u=ud.getUser("4");
		String s=u.getPwd();
		System.out.println(s);
	}

}
