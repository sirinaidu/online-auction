package asd;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.auction.dao.ProductDaoImpl;
import com.auction.model.Product;

@WebServlet("/Home")
public class Home extends HttpServlet {
       static String s="";
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		s = request.getParameter("category");
		response.sendRedirect("welcome.jsp");
		System.out.println(s);
		ProductDaoImpl pimpl=new ProductDaoImpl();
		List<Product> l=pimpl.search(s);
		request.setAttribute("list",l);
		request.setAttribute("cat", s);
	}
	public static String getS() {
		return s;
	}
	public static void setS(String s) {
		Home.s = s;
	}

}
