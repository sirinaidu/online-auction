package asd;

import java.io.IOException;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.auction.dao.ProductDaoImpl;
import com.auction.dao.SellerDaoImpl;
import com.auction.dao.UserDaoImpl;
import com.auction.model.Product;
import com.auction.model.User;

@WebServlet("/AddProduct")
public class AddProduct extends HttpServlet {
static String st = "";
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String product_name="" ;
				product_name= request.getParameter("product_name");
		String des_s ="";
		des_s = request.getParameter("short_description");
		String des_l = "";
		des_l = request.getParameter("detailed_description");
		String cat = "";
		cat = request.getParameter("category");
		Double start_price = 0.0;
		String p1="";
		p1=request.getParameter("starting _price");
		if(!(p1.equals("")))
		{
			
		start_price = Double.parseDouble(p1);
		}
		String bid_end = "";
		bid_end	= request.getParameter("bid_end_date").trim();
		bid_end=bid_end.replace('/','-');
		System.out.println(bid_end);
		Date bid_end_date = new Date();
		if(product_name.equals("") || des_s.equals("") || des_l.equals("") || start_price.equals("")
				|| bid_end.equals(""))
		{
			response.sendRedirect("addproduct.jsp");
		}
		else{
		try {
			bid_end_date = sdf.parse(bid_end);
		}
		catch (Exception e) {
		}
		String product_id = String.format("%040d", new BigInteger(UUID
				.randomUUID().toString().replace("-", ""), 16));
		Double final_price = 0.0;
		Date d = new Date();
		if(d.getTime() >= bid_end_date.getTime() )
		{
			st = "error";
			response.sendRedirect("addproduct.jsp");
		}
		else if(start_price<0)
		{
			st = "error1";
			response.sendRedirect("addproduct.jsp");
		}
		else{
		Product p = new Product(product_id, product_name, des_s, des_l, cat,
				start_price, bid_end_date, final_price, d);
		ProductDaoImpl pimpl = new ProductDaoImpl();
		System.out.println(pimpl.insertProduct(p));
		HttpSession session = request.getSession();
		String uname = (String) session.getAttribute("user");
		// System.out.println(uname);
		UserDaoImpl uimpl = new UserDaoImpl();
		User u = uimpl.getUser(uname);
		SellerDaoImpl simpl = new SellerDaoImpl();
		System.out.println(simpl.insertSeller(p.getPid(), u.getUser_id()));
		System.out.println(product_name + " " + des_s + " " + des_l + " " + cat
				+ " " + start_price + " " + bid_end);
		st="noerror";
		response.sendRedirect("addproduct.jsp");
		}
		}
	}
	public static String getSt() {
		return st;
	}
	public static void setSt(String st) {
		AddProduct.st = st;
	}
	

}
