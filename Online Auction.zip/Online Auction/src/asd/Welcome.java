package asd;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.auction.dao.*;
import com.auction.dao.UserDaoImpl;
import com.auction.model.User;

@WebServlet("/Welcome")
public class Welcome extends HttpServlet {
	static String s="";
	static String s1 ="";
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String pid = request.getParameter("pid");
		response.sendRedirect("bidCenter.jsp");	
		s = pid;
		
	}

	public static String getS() {
		return s;
	}

	public static void setS(String s) {
		Welcome.s = s;
	}

	public static String getS1() {
		return s1;
	}

	public static void setS1(String s1) {
		Welcome.s1 = s1;
	}

}
