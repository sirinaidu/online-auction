package asd;

import java.util.*;

import com.auction.dao.BuyerDaoImpl;
import com.auction.dao.ProductDaoImpl;
import com.auction.dao.SellerDaoImpl;
import com.auction.model.Product;

public class X {



	List<Purchase> l=new ArrayList<>();

	List<Sale> a=new ArrayList<>();
	List<Product> p=new ArrayList<>();

	public List<Purchase> getL() {

		return l;

	}



	public void setL(List<Purchase> l) {

		

		this.l = l;

		

	}

	public List<Sale> getA() {

		return a;

	}



	public void setA(List<Sale> a) {

		this.a = a;

	}

	public List<Product> getP() {

		return p;

	}



	public void setP(List<Product> p) {

		

		this.p = p;

		

	}

	public X()

	{
		String uid=LogIn.x;
        System.out.println(uid);
        SellerDaoImpl simpl=new SellerDaoImpl();
   
        a=simpl.sellerList(uid);
		
        BuyerDaoImpl bimpl=new BuyerDaoImpl();
    	List<Purchase> purchasesInfoList=bimpl.buyerList(uid);
		l=bimpl.buyerList(uid);
		
		ProductDaoImpl pimpl=new ProductDaoImpl();
		p=pimpl.getMyProducts(uid);
		
	}

}